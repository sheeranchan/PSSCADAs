var RefreshRate = 1000;

var TagID = 0;
var TagName = 1;
var TagValue = 2;

function query_tags()
{
	jQuery.ajax ( { url:"../rcgi.bin/ParamForm?AST_Param=$$dtIV$ftT",
	dataType:"text", success: suc, error: err, timeout: 20000 });
}

function suc(tagInfo)
{	
	
	var tag_arr = new Array();
	tag_arr = CSVToArray(tagInfo,";");
	document.getElementById("raw").innerHTML = "yunyadee";
	
	fault_led(getTagVal(tag_arr,"Fault_Mem"));
	
//	document.getElementById("text1").innerHTML = "SUCCESS";	
	var charge  = getTagVal(tag_arr,"PCS_Vab");	
	//document.getElementById("tagText").innerHTML = charge;
	//document.getElementById("tagText").innerHTML = tag_arr;
	
	setTimeout("query_tags()", RefreshRate);
}

function err()
{
	document.getElementById("text1").innerHTML = "FAIL";
	//setTimeout("show_green()",1000);
}

function fault_led(state)
{
	var grnVis = document.getElementById('grn_led');
	var redVis = document.getElementById('red_led');
	document.getElementById("tagText").innerHTML = "Fault_Mem: " + state;
	if (state != 0)
	{
		redVis.style.visibility = 'visible';
		grnVis.style.visibility = 'hidden';
	}
	else
	{
		redVis.style.visibility = 'hidden';
		grnVis.style.visibility = 'visible';
	}	
}


function getTagVal(tagArray,tag_name)
{
	var ok = "failed";
	var TagVal = "Tag Not Found";
	for(var i = 1; i<tagArray.length - 1; i++)
	{		
		if (tagArray[i][TagName] == tag_name)
		{
			TagVal =  tagArray[i][TagValue];			
			document.getElementById("debug").innerHTML = TagVal;
		}			
	}
	return TagVal;
}


function CSVToArray( strData, strDelimiter )
{
    	strDelimiter = (strDelimiter || ",");
    	var objPattern = new RegExp(
    		(
    			"(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
    			"(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
    			"([^\"\\" + strDelimiter + "\\r\\n]*))"
    		),
    		"gi"
    		);

    	var arrData = [[]];
    	var arrMatches = null;
    	while (arrMatches = objPattern.exec( strData )){
    	
    		var strMatchedDelimiter = arrMatches[ 1 ];

    		if (
    			strMatchedDelimiter.length &&
    			(strMatchedDelimiter != strDelimiter)
    			){

    			arrData.push( [] );
    		}
	if (arrMatches[ 2 ]){
    			var strMatchedValue = arrMatches[ 2 ].replace(
    				new RegExp( "\"\"", "g" ),
    				"\""
    				);
    		} else {

    			var strMatchedValue = arrMatches[ 3 ];
    		}
    		arrData[ arrData.length - 1 ].push( strMatchedValue );
    	}
    return( arrData );
}

function getDay() {
    var d = new Date();
    var n = d.getDay()
    return n;
}

query_tags();
