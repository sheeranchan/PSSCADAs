var RefreshRate = 1000;

var TagID = 0;
var TagName = 1;
var TagValue = 2;

var pcs_time_int
var savings_start
var savings_end

function query_tags()
{
	jQuery.ajax ( { url:"../rcgi.bin/ParamForm?AST_Param=$$dtIV$ftT",
	dataType:"text", success: suc, error: err, timeout: 20000 });
}

function query_historical()
{
	var query_url	
	//query_url = "../rcgi.bin/ParamForm?AST_Param=$$dtHL$ftT$st_h1$et_s0$tnMeter_Load_Energy"
	query_url = "../rcgi.bin/ParamForm?AST_Param=$$dtHL$ftT$st_h24$et_s0$tnMeter_Load_Energy"
	jQuery.ajax ( { url: query_url, 	
	dataType:"text", success: getHistorical, error: err, timeout: 20000 });
}

function suc(tagInfo)
{		
	document.getElementById("text1").innerHTML = "SUCCESS";	
	var tag_arr = new Array();
	tag_arr = CSVToArray(tagInfo,";");	
	
	fault_led(getTagVal(tag_arr,"Fault_Mem"));
	
	pcs_time_int = getTagVal(tag_arr,"pcs_time_int");	
	savings_start = getTagVal(tag_arr,"savings_start_int");	
	savings_end = getTagVal(tag_arr,"savings_end_int");	
	//var charge  = getTagVal(tag_arr,"PCS_Vab");	
	//document.getElementById("tagText").innerHTML = charge;
	//document.getElementById("tagText").innerHTML = tag_arr;
	
	setTimeout("query_tags()", RefreshRate);
}

function getHistorical(tagInfo)
{
	var tag_arr = new Array();
	tag_arr = CSVToArray(tagInfo,";");	
	
	for( var i = 1; i < tag_arr.length - 1; i++)
	{
		if(tag_arr[i][0] <= savings_start && tag_arr[i][0] <= savings_end)
		{
			document.getElementById("time").innerHTML = tag_arr[i][0] +": " + tag_arr[i][3];
				document.getElementById("raw").innerHTML = i + "  " + tag_arr.length;
		}			
	}
	
//	document.getElementById("raw").innerHTML = tag_arr[1][0] +":" + tag_arr[1][3];
	
}



function fault_led(state)
{
	var grnVis = document.getElementById('grn_led');
	var redVis = document.getElementById('red_led');
	document.getElementById("tagText").innerHTML = "Fault_Mem: " + state;
	if (state != 0)
	{
		redVis.style.visibility = 'visible';
		grnVis.style.visibility = 'hidden';
	}
	else
	{
		redVis.style.visibility = 'hidden';
		grnVis.style.visibility = 'visible';
	}	
}


function getTagVal(tagArray,tag_name)
{
	var ok = "failed";
	var TagVal = "Tag Not Found";
	for(var i = 1; i<tagArray.length - 1; i++)
	{		
		if (tagArray[i][TagName] == tag_name)
		{
			TagVal =  tagArray[i][TagValue];			
			document.getElementById("debug").innerHTML = TagVal;
		}			
	}
	return TagVal;
}

function err()
{
	document.getElementById("text1").innerHTML = "FAIL";
	//setTimeout("show_green()",1000);
}

function CSVToArray( strData, strDelimiter )
{
    	strDelimiter = (strDelimiter || ",");
    	var objPattern = new RegExp(
    		(
    			"(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
    			"(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
    			"([^\"\\" + strDelimiter + "\\r\\n]*))"
    		),
    		"gi"
    		);

    	var arrData = [[]];
    	var arrMatches = null;
    	while (arrMatches = objPattern.exec( strData )){
    	
    		var strMatchedDelimiter = arrMatches[ 1 ];

    		if (
    			strMatchedDelimiter.length &&
    			(strMatchedDelimiter != strDelimiter)
    			){

    			arrData.push( [] );
    		}
	if (arrMatches[ 2 ]){
    			var strMatchedValue = arrMatches[ 2 ].replace(
    				new RegExp( "\"\"", "g" ),
    				"\""
    				);
    		} else {

    			var strMatchedValue = arrMatches[ 3 ];
    		}
    		arrData[ arrData.length - 1 ].push( strMatchedValue );
    	}
    return( arrData );
}

function getDay() {
    var d = new Date();
    var n = d.getDay()
    return n;
}

query_tags();
query_historical();