var RefreshRate = 1000;

var TagID = 0;
var TagName = 1;
var TagValue = 2;

function query_tags()
{
	//document.getElementById("text1").innerHTML = "new TExt";
	//var imgVis = document.getElementById('led');
	//imgVis.style.visibility = 'hidden';
	
	
	
	//"10.0.0.233/rcgi.bin/ParamForm?AST_Param=$$dtTL$ftT$tnATS_SoC",
	/*
	
	jQuery.ajax ( { url:
	".../rcgi.bin/ParamForm?AST_Param=$$dtIV$ftT", 
	*/
	jQuery.ajax ( { url:"../rcgi.bin/ParamForm?AST_Param=$$dtIV$ftT",
	dataType:"text", success: suc, error: err, timeout: 20000 });
	

	//jQuery.ajax ( { url:"../10.0.0.233/ParamForm?AST_Param=$$dtTL$ftT",
	/*
	jQuery.ajax ( { url:"../rcgi.bin/ParamForm?AST_Param=$$dtTL$ftT",
	dataType:"text", success:suc, error:err, timeout:20000 });	
	*/
}

function suc(tagInfo)
{	
	document.getElementById("text1").innerHTML = "SUCCESS";
	var tag_arr = new Array();
	tag_arr = CSVToArray(tagInfo,";");
	
	tagName = "PCS_Vab";
	var charge  = getTagVal(tag_arr,tagName);	
	document.getElementById("tagText").innerHTML = charge;
	//document.getElementById("tagText").innerHTML = tag_arr;
	
	setTimeout("query_tags()", RefreshRate);
}

function err()
{
	document.getElementById("text1").innerHTML = "FAIL";
	//setTimeout("show_green()",1000);
}

function getTagVal(tagArray,tag_name)
{
	var ok = "failed";
	for(var i = 1; i<tagArray.length - 1; i++)
	{		
		if (tagArray[i][TagName] == tag_name)
		{
			ok = "success";
			document.getElementById("debug").innerHTML = tagArray[i][TagValue];
		}			
	}
	return ok;
}


function CSVToArray( strData, strDelimiter )
{
    	strDelimiter = (strDelimiter || ",");
    	var objPattern = new RegExp(
    		(
    			"(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
    			"(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
    			"([^\"\\" + strDelimiter + "\\r\\n]*))"
    		),
    		"gi"
    		);

    	var arrData = [[]];
    	var arrMatches = null;
    	while (arrMatches = objPattern.exec( strData )){
    	
    		var strMatchedDelimiter = arrMatches[ 1 ];

    		if (
    			strMatchedDelimiter.length &&
    			(strMatchedDelimiter != strDelimiter)
    			){

    			arrData.push( [] );
    		}
	if (arrMatches[ 2 ]){
    			var strMatchedValue = arrMatches[ 2 ].replace(
    				new RegExp( "\"\"", "g" ),
    				"\""
    				);
    		} else {

    			var strMatchedValue = arrMatches[ 3 ];
    		}
    		arrData[ arrData.length - 1 ].push( strMatchedValue );
    	}
    return( arrData );
}

query_tags();
